#! /bin/csh -f


      wish lastfile.tcl

      ./readxy_simplex 700 2700 1500 3300 0 
#      ./readxy2 700 2700 1500 3300 0 


      ./paw -b noiselast.kumac

      gv ps.ps &

     


