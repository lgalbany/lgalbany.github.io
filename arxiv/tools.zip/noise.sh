#!/bin/tcsh

# call this shell script followed by the name of the fits file
# and it will sample the image and produce a histogram from it.

# check if the user entered an actual filename!
# if [ -e $1 ] 
# then	
# echo $1
# else
# echo $1 'file not found!'
# pwd
# exit
# fi	

# if the symbolic links exist, delete them.

rm -f input1.fits
rm -f input2.fits

# make two new symbolic links

ln $1 input1.fits
ln $1 input2.fits

# now run the readxy program to sample the data in input1.fits
# and input2.fits and produces three files called list_ped.dat, 
# list_os.dat, and list.dat

# readxy samples the image data using a rectangular box with
# X1,Y1 in the LOWER LEFT CORNER and 
# X2,Y2 in the UPPER RIGHT CORNER

# Mind the box size, seems that the readxy program crashes if the number of 
# pixels is > 550,000.  Huh?  Paw crashes... well... sometimes.

#set X1 = 724
#set Y1 = 2700
#set X2 = 1324
#set Y2 = 3300

#echo "Sample Box lower left corner(" $X1 $Y1 ") and upper right corner(" $X2 $Y2 ")"

readxy_simplex 10 10 500 500 0

# make the the hisogram...

paw -b /home/monsoon/analysis_noise/tmp/noiselast.kumac

# rename the postscript file to something sensible...!

mv ps.ps noise_histo.ps

# now display the histogram...

gv noise_histo.ps &

# cleanup all the crap...

rm -f *.dat
rm -f paw.metafile
rm -f input1.fits
rm -f input2.fits
cp noise_histo.ps $1.ps
echo $1
