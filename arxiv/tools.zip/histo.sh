#!/bin/tcsh

# call this shell script followed by the name of the fits file
# and it will sample the image and produce a histogram from it.

# check if the user entered an actual filename!

# if [ -e $1 ] 
# then	
# echo $1
# else
# echo $1 'file not found!'
# pwd
# exit
# fi	

# if the symbolic links exist, delete them.

rm -f input1.fits
rm -f input2.fits

# make two new symbolic links

ln $1 input1.fits
ln $1 input2.fits

# now run the readxy program to sample the data in input1.fits
# and input2.fits and produces three files called list_ped.dat, 
# list_os.dat, and list.dat

# readxy samples the image data using a rectangular box with
# X1,Y1 in the LOWER LEFT CORNER and 
# X2,Y2 in the UPPER RIGHT CORNER

# Mind the box size, seems that the readxy program crashes if the number of 
# pixels is > 550,000.  Huh?  Paw crashes... well... sometimes.

#readxy_simplex 600 10 800 500 0
readxy_simplex 10 10 500 500 0

# now take list.dat and make a histogram from it.

cut -d, -f3 list.dat | sort | uniq -c > histo.dat

# run gnuplot to display histograms, make sure this is version 4.0 or 
# later so one can interact with the images.

ds9 $1 &
gnuplot /usr/tools/gnuplot_header.txt - 

