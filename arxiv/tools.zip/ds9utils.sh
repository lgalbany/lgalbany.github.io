#!/bin/bash

# some helper tools which should show up under the analysis menu
# in the DS9 viewer.  Jamieson Olsen 3 October 2006
#
# arguements are: task filename region
#
# the region argument is optional, if it is omitted then
# the entire fits image is used.  This script requires FUNTOOLS
# to be installed!

echo "/usr/tools/ds9utils.sh starting..."

# cleanup temp files

rm -f region.bin
rm -f region.dat
rm -f ps.ps

# check echo the filename and region arguements.  The funtools can be 
# picky on the region syntax.  If thngs hang that's the first thing to
# check.  JTO 4 Oct 2006

echo "filename:  $2"
echo "region(s): $3"
echo 

# make a binary table with the pixel values from the 
# specified region.  Note the [] brackets around the 
# region!

funtable "$2[$3]" region.bin

# now we have the pixels from the specified regions in the binary
# file region.bin.  What do we want to do with these pixels?

case $1 in
    "raw") fundisp region.bin;;  # dump out the raw pixel values

    "asciihisto") funhist -w region.bin value ::1;;  # make an ascii histogram

    "gnuplot") funhist -w region.bin value ::1 | funhist.plot gnuplot;;  # gnuplot graphical histogram

    "paw") fundisp -n region.bin > region.dat;   # PAW histograms
	   /usr/tools/paw -b /usr/tools/basic_histo.kumac;
	   gv ps.ps;;

    *) echo "unknown commmand $1";;
esac






